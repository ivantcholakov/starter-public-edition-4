<?php

namespace Killbill\Client\Exception;

/**
 * Main exception that occurs when communicating with the Killbill API
 */
class CurlException extends Exception
{
}
