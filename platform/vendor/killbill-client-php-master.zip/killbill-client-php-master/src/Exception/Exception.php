<?php

namespace Killbill\Client\Exception;

/**
 * General Client exception
 */
class Exception extends \Exception
{
}
