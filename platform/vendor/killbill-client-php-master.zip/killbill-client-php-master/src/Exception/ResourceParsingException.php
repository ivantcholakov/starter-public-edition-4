<?php

namespace Killbill\Client\Exception;

/**
 * Exception for resource parsing issues
 */
class ResourceParsingException extends Exception
{
}
