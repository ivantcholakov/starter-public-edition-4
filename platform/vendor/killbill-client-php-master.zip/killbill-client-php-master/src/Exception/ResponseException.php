<?php

namespace Killbill\Client\Exception;

/**
 * General response exception
 */
class ResponseException extends Exception
{
}
