# Changelog
All Notable changes to `oauth2-okta` will be documented in this file

## 0.0.1 - 2018-04-16

### Added
- Initial release!

### Deprecated
- Nothing

### Fixed
- Nothing

### Removed
- Nothing

### Security
- Nothing
