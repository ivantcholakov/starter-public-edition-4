<?php

return [
    'consul' => [
        'host' => 'app_consul',
        'port' => '8600',
    ],
];
