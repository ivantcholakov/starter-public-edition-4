<?php

return [
    'database' => [
        'connection' => [
            'host' => 'mysql',
            'dbname' => 'myapp',
            'user' => '', // ASK VAULT!
            'password' => '', // ASK VAULT!
            'driver' => 'pdo_mysql',
        ],
    ],
];
