<?php

return [
    'vault' => [
        'token' => __DIR__ . '/../../data/vault_token.json',
    ],
];
